<h2><?= $title ?></h2>
This is about page