<h2><?= $title ?></h2>
<p>Welcome to the ciBlog application</p>